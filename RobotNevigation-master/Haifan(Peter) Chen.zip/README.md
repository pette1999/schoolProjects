# CPSC390 - Robotnevigation
# Email: haichen@chapman.edu
# Student: 2326305
# Class: CPSC390
# Assignment: Assignment 2

# Citation:
+ Myatt Miller
+ Aaron Shabanian

# Files:
+ file.h
+ file.cpp
+ Grid.h
+ Grid.cpp
+ Method.h
+ Method.cpp
+ main.cpp
+ README.md

# How to run:
+ g++ -o out *.cpp
+ ./out